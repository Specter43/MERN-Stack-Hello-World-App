This package contains the core logic of Slate. Feel free to poke around to learn more!
