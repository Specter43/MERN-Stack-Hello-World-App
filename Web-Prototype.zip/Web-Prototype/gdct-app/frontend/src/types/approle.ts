export default interface AppRole {
  _id: string,
  code: string,
  name: string,
  isActive: boolean,
  updatedBy: string,
  timestamp: string,
}