export default interface Program {
  _id: string;
  code: string;
  isActive: boolean;
  name: string;
  timestamp: string;
  updatedAt: string;
  updatedBy: string;
}
