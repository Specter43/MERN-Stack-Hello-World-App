export interface MasterValue{
  _id:string;
  submission:any;
  program:any;
  templateType:any;
  reportingPeriod:string;
  categoryId:string;
  categoryName:string;
  attributeId:string;
  attributeName:string;
  org:any;
  template:string;
  value:number;
  categoryGroup:string;
  __v?:number;
}