export default interface SheetName {
  _id: string;
  id: number;
  name: string;
  isActive: boolean;
  templateTypeId: string;
  timestamp: string;
  updatedBy: string;
}
