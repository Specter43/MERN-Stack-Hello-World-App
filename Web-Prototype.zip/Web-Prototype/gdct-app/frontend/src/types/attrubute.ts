export default interface Attribute {
  _id: string,
  name: string,
  id: string,
  timestamp: string,
  updatedBy?: string,
  __v?: number,
}