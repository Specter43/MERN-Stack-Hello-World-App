export default interface AppSys {
  _id: string,
  code: string,
  name: string,
  isActive: boolean,
  timestamp: string,
  updatedBy?: string,
  __v?: number
}
