export default interface AppResource {
  _id: string,
  resourceName: string,
  resourcePath: string,
  isProtected: string,
  timestamp: string,
  updatedBy: string,
  id: number,
}