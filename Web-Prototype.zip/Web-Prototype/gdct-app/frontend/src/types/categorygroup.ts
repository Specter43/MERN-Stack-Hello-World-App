export default interface CategoryGroup {
  _id: string,
  name: string,
  __v?: number,
  timestamp: string,
  updatedBy?: string,
}