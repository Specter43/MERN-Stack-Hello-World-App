export default interface OrganizationGroup {
    label:string;
    value:{name:string, _id:string};
  }