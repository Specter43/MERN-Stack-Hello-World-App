export default interface Category {
  _id: string,
  name: string,
  id: string,
  COA: string,
  __v?: number,
  updatedBy?: string,
  unitOfMeasure: string,
  timestamp: string,
}