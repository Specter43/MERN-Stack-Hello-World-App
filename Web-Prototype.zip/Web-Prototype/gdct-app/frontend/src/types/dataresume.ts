// really unsure about this one
export default interface DataResume {
  _id: string,
  resumeArray: any[],
  currentCount: number,
  totalCount: number,
  __v?: number,
}