export { default } from './AppConfigs';
