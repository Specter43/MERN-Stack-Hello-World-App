export { default } from './COARouter';
