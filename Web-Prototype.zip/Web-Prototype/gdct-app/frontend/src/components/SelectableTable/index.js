export { default } from './SelectableTable';
