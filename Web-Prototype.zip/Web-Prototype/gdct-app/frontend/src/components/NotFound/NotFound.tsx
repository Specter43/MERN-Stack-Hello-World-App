import React from 'react';

const NotFound = () => <div>Page not found</div>;

export default NotFound;
