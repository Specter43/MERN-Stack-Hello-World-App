export const selectProgramsStore = state => state.ProgramsStore;
export const selectTemplatesStore = state => state.TemplatesStore;
