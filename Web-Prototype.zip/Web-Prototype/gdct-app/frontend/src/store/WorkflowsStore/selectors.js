export const selectWorkflowsStore = state => state.WorkflowsStore;
