export const selectAppRolesStore = state => state.AppRolesStore;
