export const selectAppResourcesStore = state => state.AppResourcesStore;
