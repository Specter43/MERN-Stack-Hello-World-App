export const selectTemplatesStore = state => state.TemplatesStore;
