export const selectAppSysesStore = state => state.AppSysesStore;
