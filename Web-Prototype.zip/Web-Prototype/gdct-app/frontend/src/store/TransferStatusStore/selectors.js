export const selectTransferStatusStore = state => state.TransferStatusStore;
