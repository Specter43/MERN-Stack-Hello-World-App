export const selectTemplateTypesStore = state => state.TemplateTypesStore;
