export const selectSubmissionPeriodsStore = state => state.SubmissionPeriodsStore;
