export const selectSheetNamesStore = state => state.SheetNamesStore;
