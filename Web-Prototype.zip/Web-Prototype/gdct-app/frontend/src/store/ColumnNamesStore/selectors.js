export const selectColumnNamesStore = state => state.ColumnNamesStore;
