export const selectAppRoleResourcesStore = state => state.AppRoleResourcesStore;
