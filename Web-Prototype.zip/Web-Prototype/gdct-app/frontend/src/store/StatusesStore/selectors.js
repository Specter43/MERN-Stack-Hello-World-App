export const selectStatusesStore = state => state.StatusesStore;
