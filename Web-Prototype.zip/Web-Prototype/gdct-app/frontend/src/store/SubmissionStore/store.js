import { createSlice } from '@reduxjs/toolkit';

const SubmissionStore = createSlice({
  name: 'SUBMISSION',
  initialState: {},
  reducers: {},
});
