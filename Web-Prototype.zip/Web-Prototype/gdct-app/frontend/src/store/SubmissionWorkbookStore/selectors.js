export const selectSubmissionWorkbookStore = state => state.SubmissionWorkbookStore;
