export const selectUserRegistrationStore = state => state.UserRegistrationStore;
