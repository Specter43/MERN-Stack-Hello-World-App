export const selectConfigurationStore = state => state.ConfigurationStore;
