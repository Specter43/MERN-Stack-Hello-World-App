export const selectSubmissionNoteHistoryStore = state => state.SubmissionNoteHistoryStore;
