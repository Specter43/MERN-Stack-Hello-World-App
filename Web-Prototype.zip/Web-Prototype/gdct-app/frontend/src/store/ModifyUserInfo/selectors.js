export const selectModifyUserInfoStore = state => state.ModifyUserInfoStore;
