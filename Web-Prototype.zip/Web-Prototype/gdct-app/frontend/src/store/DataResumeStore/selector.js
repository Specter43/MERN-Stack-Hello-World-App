export const selectDataResumeStore = state => state.DataResumeStore;
