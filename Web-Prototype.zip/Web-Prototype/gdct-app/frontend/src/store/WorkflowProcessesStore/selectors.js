export const selectWorkflowProcessesStore = state => state.WorkflowProcessesStore;
