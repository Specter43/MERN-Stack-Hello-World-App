export const selectCOATreesStore = state => state.COATreesStore;
