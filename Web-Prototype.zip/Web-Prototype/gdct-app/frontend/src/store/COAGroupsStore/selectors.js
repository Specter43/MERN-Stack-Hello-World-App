export const selectCOAGroupsStore = state => state.COAGroupsStore;
