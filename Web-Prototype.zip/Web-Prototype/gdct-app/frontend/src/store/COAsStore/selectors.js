export const selectCOAsStore = state => state.COAsStore;
