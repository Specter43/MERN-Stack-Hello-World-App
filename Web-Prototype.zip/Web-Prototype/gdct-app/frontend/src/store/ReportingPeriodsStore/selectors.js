export const selectReportingPeriodsStore = state => state.ReportingPeriodsStore;
