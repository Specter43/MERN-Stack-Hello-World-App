export const selectAppConfigsStore = state => state.AppConfigsStore;
