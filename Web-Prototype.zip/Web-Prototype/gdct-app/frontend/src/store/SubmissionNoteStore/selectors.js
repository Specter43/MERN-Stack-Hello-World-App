export const selectSubmissionNoteStore = state => state.SubmissionNoteStore;
