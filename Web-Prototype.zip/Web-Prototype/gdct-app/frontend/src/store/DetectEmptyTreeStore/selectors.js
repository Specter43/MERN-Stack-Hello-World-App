export const selectDetectEmptyTreeStore = state => state.DetectEmptyTreeStore;
