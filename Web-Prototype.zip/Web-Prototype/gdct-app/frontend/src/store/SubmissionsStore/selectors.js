export const selectSubmissionsStore = state => state.SubmissionsStore;
