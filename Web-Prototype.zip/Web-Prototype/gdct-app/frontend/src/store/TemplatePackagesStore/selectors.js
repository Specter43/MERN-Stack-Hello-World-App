export const selectTemplatePackagesStore = state => state.TemplatePackagesStore;
