export const ONLINE = 'online';
export const OFFLINE = 'offline';
