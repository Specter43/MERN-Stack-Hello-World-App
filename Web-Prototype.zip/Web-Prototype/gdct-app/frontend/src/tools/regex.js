export const sheetNameRegex = /^Sheet(\d+)$/;

export const inputCharacterRegex = /^[ -~]$/;
