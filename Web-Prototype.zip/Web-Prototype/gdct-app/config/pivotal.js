module.exports = {
  appName: "mohltctest", 
  SERVER_URL: "https://mohltctest.cfapps.io", 
  PUBLIC_URL: "https://mohltctest.cfapps.io"
};