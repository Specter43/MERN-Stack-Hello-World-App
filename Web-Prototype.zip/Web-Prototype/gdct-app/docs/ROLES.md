# Roles

Template manager
Organization manager
User manager
Bundle manager
Sector manager
Bundle manager
Bundle edit manager
Bundle review manager
Bundle approve manager
System manager
