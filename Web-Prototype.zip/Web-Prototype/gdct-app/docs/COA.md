# TODOS

add step information- flow
add instructions/feature hints
change delete - return/back to node level
placeholder - select group node instead of empty
