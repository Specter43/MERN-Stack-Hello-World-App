# Bugs

## Excel

### Rich Text

2017-18 Annual Reconciliation Report V1.xlsx

(18, 3) -- Rich text
(15, 3) -- Related to rich text

### React Object Children

2017-18 Hospital Q4 BLANK V1.xlsx - Medical Staff Renumeration

### Redux

Column/row resize
