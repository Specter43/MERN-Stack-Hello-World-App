import app from '../../app';

export const request = require('supertest')(app);
